
package main;

import conta.Conta;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Conta c1 = new Conta();
        Conta c2 = new Conta();
        
        c1.numeroAgencia = "123-2";
        c1.numeroConta = "123-2";
        
        c2.numeroAgencia = "321-2";
        c2.numeroConta = "321-2";
        
        Conta.depositar(c2, 200);
        
        c2.transferir(c1, 150);
        
        
        System.out.println("");

    }
    
}
