
package main;

import aluno.Aluno;
import aluno.AlunoMonitor;
import faculdade.Pessoa;
import funcionario.Funcionario;

public class Main {
    public static void main(String[] args) {
        Aluno a1 = new Aluno ();
        AlunoMonitor a2 = new AlunoMonitor ();
        Pessoa p1 = new Pessoa ();
        Funcionario f1 = new Funcionario ();
        
        a1.setNome("Matheus");
        a1.setCpf("07866212309");
        a1.setTelefone("88996956996");
        a1.setAula("POO");
        a1.setGennera("62931");
        a1.setMatricula("62931");
        
        a2.setNome("Joao");
        a2.setCpf("06866210200");
        a2.setTelefone("88999401900");
        a2.setCargaHorara("120 horas");
        a2.setRemuneracao("R$ 400.00");
        a2.setDisciplina("Empreendedorismo");
        
        p1.setCpf("12312312312");
        p1.setNome("Maria");
        p1.setTelefone("40028922");
       
        f1.setCpf("12312312332");
        f1.setNome("Adriano");
        f1.setTelefone("40028922");
        f1.setSalário("4000 reais");
        f1.setFuncao("Professor");
        f1.setCargaHoraria("1000 horas");
        
        System.out.println(a1.getNome()+" "+a1.getCpf()+" "+a1.getGennera()+" "+a1.getMatricula()+" "+a1.getTelefone()+" "+a1.getAula());
        System.out.println(a2.getNome()+" "+a2.getCpf()+" "+2.getTelefone()+" "+a2.getCargaHoraria()+" "+a2.getRemuneracao()+" "
        
        
    }
}
