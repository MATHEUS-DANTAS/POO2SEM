
package aluno;

public class AlunoMonitor extends Aluno{
    private String remuneracao;
    private String cargaHoraria;
    private String disciplina;
    
    public void setRemuneracao(String remuneracao){
        this.remuneracao = remuneracao;  
    }
    
    public void setCargaHorara(String cargaHoraria){
        this.cargaHoraria = cargaHoraria;
    }
    
    public void setDisciplina(String disciplina){
        this.disciplina = disciplina;
    }
    
    public String getRemuneracao(){
        return remuneracao;
    }
    
    public String getCargaHoraria(){
        return cargaHoraria;
    }
    
    public String disciplina(){
        return disciplina;
    }

}

