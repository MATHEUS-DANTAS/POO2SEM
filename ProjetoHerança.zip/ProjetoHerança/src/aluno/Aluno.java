
package aluno;

import faculdade.Pessoa;

public class Aluno extends Pessoa{
   private String matricula;
   private String gennera;
   private String aula;

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getGennera() {
        return gennera;
    }

    public void setGennera(String gennera) {
        this.gennera = gennera;
    }

    public String getAula() {
        return aula;
    }

    public void setAula(String aula) {
        this.aula = aula;
    }
   

}


