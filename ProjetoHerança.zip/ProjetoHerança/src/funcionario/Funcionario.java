
package funcionario;

import faculdade.Pessoa;

public class Funcionario extends Pessoa{
    private String salário;
    private String cargaHoraria;
    private String funcao;

    public String getSalário() {
        return salário;
    }

    public void setSalário(String salário) {
        this.salário = salário;
    }

    public String getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }
    
}
