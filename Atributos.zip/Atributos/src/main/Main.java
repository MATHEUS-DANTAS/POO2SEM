
package main;

import Aluno.aluno;




public class Main {
    public static void main(String[] args) {
        aluno a1 = new aluno();
        aluno a2 = new aluno();
        
        a1.name = "Matheus";
        a1.cidade = "Iguatu";
        a1.nacionalidade = "Brasileiro";
        a1.cpf = "078.662.123-09";
        
        a2.name = "Lucas";
        a2.cidade = "Goianesia";
        a2.nacionalidade = "Americano";
        a2.cpf = "069.688.001-60";
        
        System.out.println(a1.aluno);
        System.out.println(a2.aluno);
        
        
        
      
    }   
}
