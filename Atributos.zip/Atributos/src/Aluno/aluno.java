
package Aluno;


public class aluno {
   public String name;
   public static String nacionalidade;
   public String cpf;
   public static String cidade;
    public boolean aluno;
}