
package pessoa;


public class Pessoa {
     public String nome;
     public String cpf;
     public String nacionalidade;
     public String dataNascimento;
     public String etnia;
    
     public void andar(){
         System.out.println("Andando!");
     }
     
}

