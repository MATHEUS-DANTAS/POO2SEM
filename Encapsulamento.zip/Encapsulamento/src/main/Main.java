
package main;

import AlunoPacote.AlunoPacote;
import AlunoPrivado.AlunoPrivado;
import AlunoProtegido.AlunoProtegido;
import AlunoPublico.AlunoPublico;

public class Main {
    public static void main(String[] args) {
        AlunoPacote aluno1 = new AlunoPacote();
        AlunoPrivado aluno2 = new AlunoPrivado();
        AlunoProtegido aluno3 = new AlunoProtegido();
        AlunoPublico aluno4 = new AlunoPublico();
        
        aluno1.setNome("joao");
        aluno2.setNome("joao");
        aluno3.setNome("joao");
        aluno4.setNome("joao");
        
        System.out.println("Aluno Pacote: "+aluno1.getNome());
        System.out.println("Aluno Privado: "+aluno2.getNome());
        System.out.println("Aluno Protegino: "+aluno3.getNome());
        System.out.println("Aluno Publico: "+aluno4.getNome());
    }
   
    
}
