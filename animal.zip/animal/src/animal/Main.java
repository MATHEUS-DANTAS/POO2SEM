
package animal;

public class Main {
    public static void main(String[] args) {
        Cachorro c1 = new Cachorro("Branco",20.5, true);
        Gato g1 = new Gato("Amarelo", 5.0);
        Elefante e1 = new Elefante("Cinza", 500.00, true);
        
    }
}
