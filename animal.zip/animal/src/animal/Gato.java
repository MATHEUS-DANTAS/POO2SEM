
package animal;

public class Gato extends Animal{
    public Gato(String cor, double peso){
        super(cor, peso);
    }
    
}
