
package animal;

public class Elefante extends Animal{
    
    private boolean tromba;
            
    public Elefante(String cor, double peso, boolean tromba){
        super(cor, peso);
        
        this.tromba = tromba;
}

    public boolean isTromba() {
        return tromba;
    }

    public void setTromba(boolean tromba) {
        this.tromba = tromba;
    }
}